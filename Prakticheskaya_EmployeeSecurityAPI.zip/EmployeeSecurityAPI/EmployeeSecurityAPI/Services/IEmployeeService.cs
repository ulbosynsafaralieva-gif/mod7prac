using EmployeeSecurityAPI.Models;

namespace EmployeeSecurityAPI.Services;

public interface IEmployeeService
{
    IEnumerable<Employee> GetAll();
    Employee? GetById(int id);
    IEnumerable<Employee> GetByGender(string gender);
}
