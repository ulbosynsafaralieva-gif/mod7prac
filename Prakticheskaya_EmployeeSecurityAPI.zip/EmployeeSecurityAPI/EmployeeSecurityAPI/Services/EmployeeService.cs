using EmployeeSecurityAPI.Models;

namespace EmployeeSecurityAPI.Services;

public class EmployeeService : IEmployeeService
{
    private readonly List<Employee> _employees = new()
    {
        new Employee { Id = 1,  Name = "Айдар Сериков",     Department = "IT",         Gender = "Male",   Salary = 850000 },
        new Employee { Id = 2,  Name = "Динара Нурлановна", Department = "IT",         Gender = "Female", Salary = 900000 },
        new Employee { Id = 3,  Name = "Ержан Касымов",     Department = "HR",         Gender = "Male",   Salary = 520000 },
        new Employee { Id = 4,  Name = "Мадина Алиева",     Department = "HR",         Gender = "Female", Salary = 540000 },
        new Employee { Id = 5,  Name = "Нурлан Ахметов",    Department = "Finance",    Gender = "Male",   Salary = 780000 },
        new Employee { Id = 6,  Name = "Айгерим Бекова",    Department = "Finance",    Gender = "Female", Salary = 760000 },
        new Employee { Id = 7,  Name = "Тимур Жумабаев",    Department = "Marketing",  Gender = "Male",   Salary = 610000 },
        new Employee { Id = 8,  Name = "Сабина Омарова",    Department = "Marketing",  Gender = "Female", Salary = 640000 },
        new Employee { Id = 9,  Name = "Данияр Оспанов",    Department = "Operations", Gender = "Male",   Salary = 570000 },
        new Employee { Id = 10, Name = "Жанар Исмаилова",   Department = "Operations", Gender = "Female", Salary = 590000 },
        new Employee { Id = 11, Name = "Руслан Таков",      Department = "IT",         Gender = "Male",   Salary = 950000 },
        new Employee { Id = 12, Name = "Алия Сулейменова",  Department = "Finance",    Gender = "Female", Salary = 820000 }
    };

    public IEnumerable<Employee> GetAll() => _employees;

    public Employee? GetById(int id) => _employees.FirstOrDefault(e => e.Id == id);

    public IEnumerable<Employee> GetByGender(string gender) =>
        _employees.Where(e => string.Equals(e.Gender, gender, StringComparison.OrdinalIgnoreCase));
}
